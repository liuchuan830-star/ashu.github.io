#!/bin/bash

# 启动Python简易服务器
echo "Starting Python server on port 8000..."
echo "Open your browser and navigate to http://localhost:8000"
python3 -m http.server 8000
